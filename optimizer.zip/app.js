const SAMPLE=`Rice, Dal, Oil, Salt
Rice, Dal, Turmeric
Tea, Sugar, Milk Powder
Tea, Biscuits, Sugar
Rice, Oil, Onion
Dal, Turmeric, Salt
Soap, Shampoo, Toothpaste
Noodles, Ketchup, Oil
Tea, Biscuits
Rice, Dal, Salt, Oil
Shampoo, Soap
Noodles, Ketchup`;
const PRESETS={
  grocery:{label:'Grocery',pick:'Rice, Dal, Tea, Biscuits, Shampoo',orders:`Rice, Dal, Oil, Salt
Rice, Dal, Turmeric
Tea, Sugar, Milk
Tea, Biscuits, Sugar
Rice, Oil, Onion
Dal, Turmeric, Salt
Soap, Shampoo, Toothpaste
Noodles, Ketchup, Oil
Tea, Biscuits
Rice, Dal, Salt, Oil
Shampoo, Soap
Noodles, Ketchup`},
  household:{label:'Household',pick:'Detergent, Towels, Broom, Batteries',orders:`Detergent, Fabric Softener, Cloths
Broom, Mop, Floor Cleaner
Trash Bags, Paper Towels, Sponges
Light Bulbs, Batteries, Tape
Detergent, Sponges, Trash Bags
Mop, Floor Cleaner, Cloths
Paper Towels, Toilet Paper, Soap
Broom, Dustpan, Trash Bags
Batteries, Light Bulbs, Extension Cord
Towels, Hangers, Storage Box`},
  personal:{label:'Personal Care',pick:'Shampoo, Toothpaste, Face Wash, Deodorant',orders:`Shampoo, Conditioner, Hair Oil
Toothpaste, Toothbrush, Mouthwash
Face Wash, Moisturizer, Sunscreen
Soap, Body Wash, Loofah
Deodorant, Perfume, Body Lotion
Shampoo, Conditioner, Face Wash
Toothpaste, Mouthwash, Soap
Sanitary Pads, Handwash, Tissues
Face Wash, Sunscreen, Lip Balm
Deodorant, Body Wash, Shampoo`},
  cafe:{label:'Café Supplies',pick:'Coffee Beans, Milk, Croissant, Cups',orders:`Coffee Beans, Milk, Sugar
Tea Bags, Sugar, Paper Cups
Croissant, Butter, Jam
Coffee Beans, Paper Cups, Napkins
Milk, Chocolate Syrup, Whipped Cream
Sandwich Bread, Cheese, Lettuce
Coffee Beans, Milk, Cookies
Tea Bags, Lemon, Honey
Croissant, Coffee Beans, Napkins
Paper Cups, Lids, Straws`}
};
const $=id=>document.getElementById(id);
const COLS=8,ROWS=6;
const distance=(a,b)=>Math.abs(a.x-b.x)+Math.abs(a.y-b.y);
const escapeHtml=value=>value.replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));

/* MODULE 1 — algorithm selection records the real algorithms run in this app. */
function selectAlgorithms(){return{search:'Rabin-Karp · O(n + m)',route:'Bitmask DP / TSP · O(n² × 2ⁿ)',flow:'Edmonds-Karp · O(VE²)',approx:'Nearest Neighbor · O(n²)',sampling:'Reservoir sampling · O(n)',hash:'Randomized polynomial hash · O(n)'}}

/* MODULE 2 — Rabin-Karp string matching, implemented without includes/indexOf/regex search. */
function rabinKarp(text,pattern){const source=text.toLowerCase(),query=pattern.toLowerCase(),base=257,mod=1000000007;if(!query||query.length>source.length)return[];let factor=1,ph=0,th=0;for(let i=0;i<query.length;i++){ph=(ph*base+query.charCodeAt(i))%mod;th=(th*base+source.charCodeAt(i))%mod;if(i<query.length-1)factor=(factor*base)%mod}const hits=[];for(let start=0;start<=source.length-query.length;start++){if(ph===th){let same=true;for(let j=0;j<query.length;j++)if(source.charCodeAt(start+j)!==query.charCodeAt(j)){same=false;break}if(same)hits.push(start)}if(start<source.length-query.length){th=(th-source.charCodeAt(start)*factor)%mod;if(th<0)th+=mod;th=(th*base+source.charCodeAt(start+query.length))%mod}}return hits}

/* MODULE 4 — Edmonds-Karp maximum flow using BFS residual paths. */
function edmondsKarp(capacity,source,sink){const residual=capacity.map(row=>row.slice());let maxFlow=0;while(true){const parent=Array(residual.length).fill(-1),queue=[source];parent[source]=source;for(let head=0;head<queue.length&&parent[sink]===-1;head++){const u=queue[head];for(let v=0;v<residual.length;v++)if(parent[v]===-1&&residual[u][v]>0){parent[v]=u;queue.push(v);if(v===sink)break}}if(parent[sink]===-1)break;let path=Infinity;for(let v=sink;v!==source;v=parent[v])path=Math.min(path,residual[parent[v]][v]);for(let v=sink;v!==source;v=parent[v]){residual[parent[v]][v]-=path;residual[v][parent[v]]+=path}maxFlow+=path}return maxFlow}
function zoneCapacityFlow(positions){const workers=2,zones=3,source=0,workerStart=1,zoneStart=workerStart+workers,sink=zoneStart+zones,size=sink+1;const cap=Array.from({length:size},()=>Array(size).fill(0));for(let w=0;w<workers;w++){cap[source][workerStart+w]=4;for(let z=0;z<zones;z++)cap[workerStart+w][zoneStart+z]=4}const demand=[0,0,0];positions.forEach(p=>demand[Math.min(2,Math.floor(p.y/2))]++);for(let z=0;z<zones;z++)cap[zoneStart+z][sink]=Math.min(4,demand[z]);return edmondsKarp(cap,source,sink)}

/* MODULE 5 — Nearest-Neighbor approximation, intentionally separate from exact TSP. */
function nearestNeighbor(points){const remaining=points.slice(1).map((_,i)=>i),order=[];let current=points[0],total=0;while(remaining.length){let best=0;for(let i=1;i<remaining.length;i++)if(distance(current,points[remaining[i]+1])<distance(current,points[remaining[best]+1]))best=i;const next=remaining.splice(best,1)[0];total+=distance(current,points[next+1]);current=points[next+1];order.push(next)}return{total:total+distance(current,points[0]),order}}

/* MODULE 6 — randomized hashing, reservoir sampling and independent chunk reduction. */
function randomizedHash(text){const base=257+Math.floor(Math.random()*500),mod=1000000007;let hash=0;for(let i=0;i<text.length;i++)hash=(hash*base+text.charCodeAt(i))%mod;return{base,hash}}
function reservoirSample(items,size){const sample=items.slice(0,size);for(let i=size;i<items.length;i++){const j=Math.floor(Math.random()*(i+1));if(j<size)sample[j]=items[i]}return sample}
function parallelStyleFrequency(orders,productCount){const chunks=[[],[]];orders.forEach((order,index)=>chunks[index%2].push(order));const partial=chunks.map(chunk=>{const counts=Array(productCount).fill(0);chunk.forEach(order=>order.forEach(item=>counts[item]++));return counts});return partial.reduce((sum,chunk)=>sum.map((value,index)=>value+chunk[index]),Array(productCount).fill(0))}

/* Data module: order parsing, product popularity and co-order counts. */
function buildWarehouse(){
  const lines=$('orders').value.split('\n').map(line=>line.trim()).filter(Boolean);
  const names=[],orders=[];
  const find=name=>names.findIndex(item=>item.toLowerCase()===name.toLowerCase());
  for(const line of lines){const order=[];for(let product of line.split(',')){product=product.trim();if(!product)continue;product=product[0].toUpperCase()+product.slice(1);let index=find(product);if(index<0){names.push(product);index=names.length-1}if(!order.includes(index))order.push(index)}if(order.length)orders.push(order)}
  if(!names.length)throw new Error('Add at least one order first.');
  if(names.length>COLS*ROWS-1)throw new Error(`Too many products. The simple map holds ${COLS*ROWS-1} products plus the door.`);
  const freq=Array(names.length).fill(0),co=Array.from({length:names.length},()=>Array(names.length).fill(0));
  orders.forEach(order=>order.forEach(a=>{freq[a]++;order.forEach(b=>{if(a!==b)co[a][b]++})}));
  /* Fixed shelves: product placement does not change when a route is sorted. */
  const depot={x:0,y:0};
  const pos=names.map((_,index)=>{const cell=index+1;return{x:cell%COLS,y:Math.floor(cell/COLS)}});
  const analysis={selection:selectAlgorithms(),hash:randomizedHash(lines.join('\n')),sample:reservoirSample(orders,Math.min(5,orders.length)),parallelFrequency:parallelStyleFrequency(orders,names.length),maxFlow:zoneCapacityFlow(pos)};
  return {names,freq,co,pos,depot,find,orders,analysis};
}

/* Route module: exact travelling-salesperson search for up to 12 products. */
function optimize(points){
  const count=points.length-1,size=1<<count;
  const dp=Array.from({length:size},()=>Array(count).fill(Infinity)),parent=Array.from({length:size},()=>Array(count).fill(-1));
  for(let i=0;i<count;i++)dp[1<<i][i]=distance(points[0],points[i+1]);
  for(let mask=1;mask<size;mask++)for(let last=0;last<count;last++){if(!(mask>>last&1)||!Number.isFinite(dp[mask][last]))continue;for(let next=0;next<count;next++){if(mask>>next&1)continue;const nextMask=mask|1<<next,value=dp[mask][last]+distance(points[last+1],points[next+1]);if(value<dp[nextMask][next]){dp[nextMask][next]=value;parent[nextMask][next]=last}}}
  let total=Infinity,last=0;for(let i=0;i<count;i++){const value=dp[size-1][i]+distance(points[i+1],points[0]);if(value<total){total=value;last=i}}
  const order=[];let mask=size-1;while(last>=0){order.unshift(last);const previous=parent[mask][last];mask^=1<<last;last=previous}return{total,order};
}

/* Map module: intentionally simple rectangular aisle/shelf grid. */
function renderMap(route=null){
  if(!state)return;$('map').innerHTML='';
  const picked=new Set(route?.picks||[]),steps=new Map((route?.sequence||[]).map((item,index)=>[item,index+1]));
  const at=new Map(state.pos.map((position,index)=>[`${position.x},${position.y}`,index]));
  for(let y=0;y<ROWS;y++)for(let x=0;x<COLS;x++){
    const cell=document.createElement('div');const product=at.get(`${x},${y}`);
    if(x===0&&y===0){cell.className='shelf door';cell.textContent='DOOR'}else if(product===undefined){cell.className='shelf empty-shelf';cell.textContent=`Shelf ${y+1}-${x+1}`}else{cell.className=`shelf${picked.has(product)?' pick':''}${steps.has(product)?' route':''}`;cell.dataset.step=steps.get(product)||'';cell.innerHTML=`Shelf ${y+1}-${x+1}<strong>${escapeHtml(state.names[product])}</strong>`}$('map').append(cell)
  }
}

let state=null;
function selectedProducts(){return [...document.querySelectorAll('[data-pick-product]:checked')].map(input=>input.value)}
function renderProductPicker(selected=[]){
  const selectedSet=new Set(selected);
  $('availableProducts').innerHTML=state.names.map(name=>`<label class="product-option"><input type="checkbox" data-pick-product value="${escapeHtml(name)}" ${selectedSet.has(name)?'checked':''}>${escapeHtml(name)}</label>`).join('');
}
function renderAnalysis(exact=null,approximate=null){
  if(!state){$('analysis').innerHTML='';return}const a=state.analysis,overhead=exact&&approximate&&exact.total?Math.max(0,((approximate.total-exact.total)/exact.total*100)).toFixed(1):'—';
  $('analysis').innerHTML=`<h3>DSA-3 Algorithms Used</h3><div class="analysis-grid"><div class="analysis-card"><b>Module 1 · Algorithm selection</b><span>${a.selection.route}</span></div><div class="analysis-card"><b>Module 2 · Rabin-Karp</b><span>Search is active in Enter Data.</span></div><div class="analysis-card"><b>Module 3 · Exact Bitmask DP + TSP</b><span>${exact?`${exact.total} steps`:'Select products'} · O(n² × 2ⁿ)</span></div><div class="analysis-card"><b>Module 4 · Edmonds-Karp Max Flow</b><span>Zone capacity assignments: ${a.maxFlow} · O(VE²)</span></div><div class="analysis-card"><b>Module 5 · Nearest Neighbor Approximation</b><span>${approximate?`${approximate.total} steps · ${overhead}% overhead`:'Select products'} · O(n²)</span></div><div class="analysis-card"><b>Module 6 · Randomized / reduction</b><span>Hash base ${a.hash.base}; reservoir sample ${a.sample.length}/${state.orders.length}; 2-chunk reduction complete.</span></div></div>`;
}
function run(){
  const message=$('msg');message.textContent='';
  try{state=buildWarehouse()}catch(error){message.textContent=error.message;return}
  renderProductPicker(selectedProducts());
  const raw=selectedProducts(),picks=[],notes=[];
  raw.forEach(name=>{const index=state.find(name);if(index<0)notes.push(`“${name}” is not in the warehouse map`);else if(!picks.includes(index))picks.push(index)});
  if(picks.length>12){message.textContent='Pick lists are limited to 12 products.';picks.length=12}else message.textContent=notes.join('. ');
  if(!picks.length){renderMap();$('stats').innerHTML='';$('steps').innerHTML='<li class="empty">No matching products in the pick list.</li>';$('rec').innerHTML='<li class="empty">Nothing to suggest yet.</li>';renderAnalysis();return}
  const result=optimize([state.depot,...picks.map(index=>state.pos[index])]);
  const approximate=nearestNeighbor([state.depot,...picks.map(index=>state.pos[index])]);
  const sequence=result.order.map(index=>picks[index]);let naive=0,previous=state.depot;
  picks.forEach(index=>{naive+=distance(previous,state.pos[index]);previous=state.pos[index]});naive+=distance(previous,state.depot);
  const recommendations=state.names.map((_,index)=>[index,picks.reduce((sum,pick)=>sum+state.co[pick][index],0)]).filter(([index,score])=>!picks.includes(index)&&score).sort((a,b)=>b[1]-a[1]).slice(0,4);
  renderMap({picks,sequence});
  const saved=naive?Math.round((naive-result.total)/naive*100):0;
  $('stats').innerHTML=`<div><b>${result.total}</b><span>steps, shortest loop</span></div><div><b>${naive}</b><span>steps in typed order</span></div><div><b>${saved}%</b><span>walking saved</span></div>`;
  let list='',from=state.depot;sequence.forEach((index,step)=>{list+=`<li><span>${step+1}. ${escapeHtml(state.names[index])}</span><em>${distance(from,state.pos[index])} steps</em></li>`;from=state.pos[index]});list+=`<li><span>Back to door</span><em>${distance(from,state.depot)} steps</em></li>`;$('steps').innerHTML=list;
  $('rec').innerHTML=recommendations.length?recommendations.map(([index,score])=>`<li><span>${escapeHtml(state.names[index])}<br><em>seen with your items ${score} times</em></span><button class="alt" data-product="${escapeHtml(state.names[index])}">Add</button></li>`).join(''):'<li class="empty">No other product shares an order with this list.</li>';
  renderAnalysis(result,approximate);
}

function show(tab){document.querySelectorAll('main section').forEach(section=>section.hidden=section.id!==`s-${tab}`);document.querySelectorAll('#tabs button').forEach(button=>button.setAttribute('aria-selected',button.dataset.t===tab));window.scrollTo(0,0)}
function runSearch(){const query=$('searchText').value.trim();if(!query){$('searchResult').textContent='Enter a product or order phrase to search.';return}const hits=rabinKarp($('orders').value,query);$('searchResult').textContent=`Rabin-Karp found ${hits.length} match${hits.length===1?'':'es'} in the order data.`}
document.addEventListener('click',event=>{const tab=event.target.dataset.t||event.target.dataset.go;if(tab)show(tab);const preset=event.target.closest('[data-preset]')?.dataset.preset;if(preset){const data=PRESETS[preset];$('orders').value=data.orders;run();renderProductPicker(data.pick.split(', '));$('msg').textContent=`${data.label} preset loaded. Select available products and optimize the route.`}const product=event.target.dataset.product;if(product){const box=[...document.querySelectorAll('[data-pick-product]')].find(input=>input.value===product);if(box){box.checked=true;run()}}});
$('go').onclick=()=>{run();show('map')};$('find').onclick=run;$('searchBtn').onclick=runSearch;$('searchText').onkeydown=event=>{if(event.key==='Enter')runSearch()};$('reset').onclick=()=>{$('orders').value=PRESETS.grocery.orders;run();renderProductPicker(PRESETS.grocery.pick.split(', '));$('msg').textContent='Grocery preset loaded.'};$('orders').value=PRESETS.grocery.orders;run();renderProductPicker(PRESETS.grocery.pick.split(', '));
